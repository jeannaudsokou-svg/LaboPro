-- ============================================
-- SCRIPT SQL - GESTION LABORATOIRE MEDICAL
-- Base de données: labo_medical
-- ============================================

-- Création de la base de données
CREATE DATABASE IF NOT EXISTS labo_medical CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE labo_medical;

-- ============================================
-- TABLE: utilisateurs (classe parent)
-- ============================================
CREATE TABLE IF NOT EXISTS utilisateurs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    mot_de_passe VARCHAR(255) NOT NULL,
    telephone VARCHAR(20),
    role ENUM('administrateur', 'receptionniste', 'technicien') NOT NULL,
    statut ENUM('actif', 'inactif') DEFAULT 'actif',
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    derniere_connexion TIMESTAMP NULL
);

-- ============================================
-- TABLE: patients
-- ============================================
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY AUTO_INCREMENT,
    numero_dossier VARCHAR(20) UNIQUE NOT NULL,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    date_naissance DATE NOT NULL,
    sexe ENUM('M', 'F') NOT NULL,
    adresse TEXT,
    telephone VARCHAR(20) NOT NULL,
    email VARCHAR(150),
    groupe_sanguin VARCHAR(5),
    allergies TEXT,
    antecedents_medicaux TEXT,
    date_inscription TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    enregistre_par INT,
    FOREIGN KEY (enregistre_par) REFERENCES utilisateurs(id)
);

-- ============================================
-- TABLE: types_examens
-- ============================================
CREATE TABLE IF NOT EXISTS types_examens (
    id INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(20) UNIQUE NOT NULL,
    nom VARCHAR(150) NOT NULL,
    description TEXT,
    categorie VARCHAR(100),
    prix DECIMAL(10,2) NOT NULL,
    delai_resultat INT DEFAULT 24, -- en heures
    valeurs_normales TEXT,
    actif BOOLEAN DEFAULT TRUE
);

-- ============================================
-- TABLE: rendez_vous
-- ============================================
CREATE TABLE IF NOT EXISTS rendez_vous (
    id INT PRIMARY KEY AUTO_INCREMENT,
    patient_id INT NOT NULL,
    date_rdv DATE NOT NULL,
    heure_rdv TIME NOT NULL,
    motif TEXT,
    statut ENUM('planifie', 'confirme', 'en_cours', 'termine', 'annule') DEFAULT 'planifie',
    notes TEXT,
    cree_par INT,
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id),
    FOREIGN KEY (cree_par) REFERENCES utilisateurs(id)
);

-- ============================================
-- TABLE: demandes_examens
-- ============================================
CREATE TABLE IF NOT EXISTS demandes_examens (
    id INT PRIMARY KEY AUTO_INCREMENT,
    patient_id INT NOT NULL,
    rendez_vous_id INT,
    medecin_prescripteur VARCHAR(150),
    date_demande TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    statut ENUM('en_attente', 'en_cours', 'termine', 'annule') DEFAULT 'en_attente',
    priorite ENUM('normale', 'urgente') DEFAULT 'normale',
    observations TEXT,
    cree_par INT,
    FOREIGN KEY (patient_id) REFERENCES patients(id),
    FOREIGN KEY (rendez_vous_id) REFERENCES rendez_vous(id),
    FOREIGN KEY (cree_par) REFERENCES utilisateurs(id)
);

-- ============================================
-- TABLE: examens (détails des examens demandés)
-- ============================================
CREATE TABLE IF NOT EXISTS examens (
    id INT PRIMARY KEY AUTO_INCREMENT,
    demande_id INT NOT NULL,
    type_examen_id INT NOT NULL,
    statut ENUM('en_attente', 'preleve', 'en_analyse', 'termine', 'annule') DEFAULT 'en_attente',
    date_prelevement TIMESTAMP NULL,
    preleve_par INT,
    FOREIGN KEY (demande_id) REFERENCES demandes_examens(id),
    FOREIGN KEY (type_examen_id) REFERENCES types_examens(id),
    FOREIGN KEY (preleve_par) REFERENCES utilisateurs(id)
);

-- ============================================
-- TABLE: resultats
-- ============================================
CREATE TABLE IF NOT EXISTS resultats (
    id INT PRIMARY KEY AUTO_INCREMENT,
    examen_id INT NOT NULL,
    valeur TEXT NOT NULL,
    unite VARCHAR(50),
    valeur_normale VARCHAR(100),
    interpretation ENUM('normal', 'anormal_bas', 'anormal_haut', 'critique') DEFAULT 'normal',
    commentaire TEXT,
    date_saisie TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    saisi_par INT,
    valide BOOLEAN DEFAULT FALSE,
    date_validation TIMESTAMP NULL,
    valide_par INT,
    FOREIGN KEY (examen_id) REFERENCES examens(id),
    FOREIGN KEY (saisi_par) REFERENCES utilisateurs(id),
    FOREIGN KEY (valide_par) REFERENCES utilisateurs(id)
);

-- ============================================
-- TABLE: paiements
-- ============================================
CREATE TABLE IF NOT EXISTS paiements (
    id INT PRIMARY KEY AUTO_INCREMENT,
    demande_id INT NOT NULL,
    montant_total DECIMAL(10,2) NOT NULL,
    montant_paye DECIMAL(10,2) DEFAULT 0,
    mode_paiement ENUM('especes', 'carte', 'virement', 'assurance') DEFAULT 'especes',
    statut ENUM('en_attente', 'partiel', 'paye', 'rembourse') DEFAULT 'en_attente',
    reference_paiement VARCHAR(50),
    date_paiement TIMESTAMP NULL,
    encaisse_par INT,
    FOREIGN KEY (demande_id) REFERENCES demandes_examens(id),
    FOREIGN KEY (encaisse_par) REFERENCES utilisateurs(id)
);

-- ============================================
-- TABLE: notifications
-- ============================================
CREATE TABLE IF NOT EXISTS notifications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    destinataire_type ENUM('utilisateur', 'patient') NOT NULL,
    destinataire_id INT NOT NULL,
    titre VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('info', 'alerte', 'rappel', 'resultat') DEFAULT 'info',
    lu BOOLEAN DEFAULT FALSE,
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    date_lecture TIMESTAMP NULL
);

-- ============================================
-- TABLE: historique_actions (audit)
-- ============================================
CREATE TABLE IF NOT EXISTS historique_actions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    utilisateur_id INT,
    action VARCHAR(100) NOT NULL,
    table_concernee VARCHAR(50),
    enregistrement_id INT,
    details TEXT,
    adresse_ip VARCHAR(45),
    date_action TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id)
);

-- ============================================
-- DONNEES INITIALES
-- ============================================

-- Administrateur par défaut (mot de passe: admin123)
INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe, telephone, role, statut)
VALUES ('Admin', 'Système', 'admin@labo.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '0600000000', 'administrateur', 'actif');

-- Réceptionniste test (mot de passe: receptionniste123)
INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe, telephone, role, statut)
VALUES ('Dupont', 'Marie', 'receptionniste@labo.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '0611111111', 'receptionniste', 'actif');

-- Technicien test (mot de passe: technicien123)
INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe, telephone, role, statut)
VALUES ('Martin', 'Jean', 'technicien@labo.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '0622222222', 'technicien', 'actif');

-- Types d'examens courants
INSERT INTO types_examens (code, nom, description, categorie, prix, delai_resultat, valeurs_normales) VALUES
('NFS', 'Numération Formule Sanguine', 'Analyse complète des cellules sanguines', 'Hématologie', 35.00, 4, 'Voir résultats détaillés'),
('GLY', 'Glycémie à jeun', 'Mesure du taux de glucose sanguin', 'Biochimie', 15.00, 2, '0.70 - 1.10 g/L'),
('CHOL', 'Cholestérol total', 'Mesure du cholestérol sanguin', 'Biochimie', 20.00, 2, '< 2.00 g/L'),
('TG', 'Triglycérides', 'Mesure des triglycérides', 'Biochimie', 20.00, 2, '< 1.50 g/L'),
('CREAT', 'Créatinine', 'Évaluation de la fonction rénale', 'Biochimie', 18.00, 2, '7 - 13 mg/L'),
('UREE', 'Urée sanguine', 'Évaluation de la fonction rénale', 'Biochimie', 15.00, 2, '0.15 - 0.45 g/L'),
('ASAT', 'ASAT (TGO)', 'Enzyme hépatique', 'Biochimie', 18.00, 2, '< 35 UI/L'),
('ALAT', 'ALAT (TGP)', 'Enzyme hépatique', 'Biochimie', 18.00, 2, '< 45 UI/L'),
('TSH', 'TSH ultrasensible', 'Hormone thyroïdienne', 'Hormonologie', 35.00, 24, '0.4 - 4.0 mUI/L'),
('HBA1C', 'Hémoglobine glyquée', 'Contrôle du diabète', 'Biochimie', 40.00, 24, '< 6.5 %'),
('ECBU', 'Examen cytobactériologique des urines', 'Recherche d\'infection urinaire', 'Bactériologie', 30.00, 48, 'Absence de germes'),
('VS', 'Vitesse de sédimentation', 'Marqueur inflammatoire', 'Hématologie', 12.00, 1, 'H: < 15 mm/h, F: < 20 mm/h'),
('CRP', 'Protéine C Réactive', 'Marqueur inflammatoire', 'Biochimie', 25.00, 2, '< 6 mg/L'),
('TP', 'Taux de Prothrombine', 'Coagulation sanguine', 'Hémostase', 20.00, 2, '70 - 100 %'),
('GS', 'Groupe Sanguin + Rhésus', 'Détermination du groupe sanguin', 'Immuno-hématologie', 25.00, 4, 'A, B, AB ou O / Rh+ ou Rh-');

-- Patients exemples
INSERT INTO patients (numero_dossier, nom, prenom, date_naissance, sexe, adresse, telephone, email, groupe_sanguin, enregistre_par) VALUES
('PAT-2024-001', 'Dubois', 'Sophie', '1985-03-15', 'F', '123 Rue de Paris, 75001 Paris', '0633333333', 'sophie.dubois@email.com', 'A+', 2),
('PAT-2024-002', 'Bernard', 'Pierre', '1972-08-22', 'M', '456 Avenue des Champs, 75008 Paris', '0644444444', 'pierre.bernard@email.com', 'O-', 2),
('PAT-2024-003', 'Leroy', 'Isabelle', '1990-12-01', 'F', '789 Boulevard Saint-Germain, 75006 Paris', '0655555555', 'isabelle.leroy@email.com', 'B+', 2);

-- ============================================
-- INDEX POUR OPTIMISATION
-- ============================================
CREATE INDEX idx_patients_numero ON patients(numero_dossier);
CREATE INDEX idx_patients_nom ON patients(nom, prenom);
CREATE INDEX idx_rdv_date ON rendez_vous(date_rdv);
CREATE INDEX idx_rdv_patient ON rendez_vous(patient_id);
CREATE INDEX idx_examens_statut ON examens(statut);
CREATE INDEX idx_resultats_examen ON resultats(examen_id);
CREATE INDEX idx_notifications_destinataire ON notifications(destinataire_type, destinataire_id);
