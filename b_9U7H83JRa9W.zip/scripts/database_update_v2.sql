-- ============================================
-- MISE A JOUR BASE DE DONNEES V2
-- Ajout du rôle patient et nouvelles fonctionnalités
-- ============================================

USE labo_medical;

-- ============================================
-- 1. MODIFIER LA TABLE utilisateurs pour ajouter le rôle patient
-- ============================================
ALTER TABLE utilisateurs 
MODIFY COLUMN role ENUM('administrateur', 'receptionniste', 'technicien', 'patient') NOT NULL;

-- ============================================
-- 2. Ajouter la colonne patient_id pour lier utilisateur patient à sa fiche patient
-- ============================================
ALTER TABLE utilisateurs 
ADD COLUMN patient_id INT NULL AFTER role,
ADD FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE SET NULL;

-- ============================================
-- 3. Modifier la table notifications pour améliorer le système
-- ============================================
ALTER TABLE notifications 
ADD COLUMN lien VARCHAR(255) NULL AFTER type,
ADD COLUMN reference_id INT NULL AFTER lien,
ADD COLUMN reference_type VARCHAR(50) NULL AFTER reference_id;

-- ============================================
-- 4. Créer un patient utilisateur de test
-- ============================================
-- Mot de passe: password
INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe, telephone, role, statut, patient_id)
SELECT 'Dubois', 'Sophie', 'patient@labo.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '0633333333', 'patient', 'actif', 1
WHERE NOT EXISTS (SELECT 1 FROM utilisateurs WHERE email = 'patient@labo.com');

-- ============================================
-- INDEX SUPPLEMENTAIRES
-- ============================================
CREATE INDEX IF NOT EXISTS idx_notifications_reference ON notifications(reference_type, reference_id);
CREATE INDEX IF NOT EXISTS idx_utilisateurs_patient ON utilisateurs(patient_id);
